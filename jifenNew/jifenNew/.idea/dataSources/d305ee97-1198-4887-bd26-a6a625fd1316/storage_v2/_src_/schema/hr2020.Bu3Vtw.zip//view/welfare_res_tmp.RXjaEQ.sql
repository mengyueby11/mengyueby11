create view welfare_res_tmp as
select `t`.`settlementPeriodId`                                      AS `settlementPeriodId`,
       `t`.`结算期`                                                     AS `结算期`,
       `t`.`deptCode`                                                AS `deptCode`,
       `t`.`treeSign`                                                AS `treeSign`,
       `t`.`部门`                                                      AS `部门`,
       `t`.`岗位`                                                      AS `岗位`,
       `t`.`姓名`                                                      AS `姓名`,
       `t`.`工号`                                                      AS `工号`,
       `t`.`身份证号`                                                    AS `身份证号`,
       round(sum(`t`.`合计缴纳`), 2)                                     AS `合计缴纳`,
       round(sum(`t`.`利息`), 2)                                       AS `利息`,
       round(sum(`t`.`滞纳金`), 2)                                      AS `滞纳金`,
       max((case when (`t`.`险种类型` = '企业基本养老保险') then `t`.`单位缴` end)) AS `企业基本养老保险-单位缴`,
       max((case when (`t`.`险种类型` = '企业基本养老保险') then `t`.`个人缴` end)) AS `企业基本养老保险-个人缴`,
       max((case when (`t`.`险种类型` = '失业保险') then `t`.`单位缴` end))     AS `失业保险-单位缴`,
       max((case when (`t`.`险种类型` = '失业保险') then `t`.`个人缴` end))     AS `失业保险-个人缴`,
       max((case when (`t`.`险种类型` = '基本医疗保险') then `t`.`单位缴` end))   AS `基本医疗保险-单位缴`,
       max((case when (`t`.`险种类型` = '基本医疗保险') then `t`.`个人缴` end))   AS `基本医疗保险-个人缴`,
       max((case when (`t`.`险种类型` = '工伤保险') then `t`.`单位缴` end))     AS `工伤保险-单位缴`,
       max((case when (`t`.`险种类型` = '工伤保险') then `t`.`个人缴` end))     AS `工伤保险-个人缴`,
       max((case when (`t`.`险种类型` = '生育保险') then `t`.`单位缴` end))     AS `生育保险-单位缴`,
       max((case when (`t`.`险种类型` = '生育保险') then `t`.`个人缴` end))     AS `生育保险-个人缴`,
       max((case when (`t`.`险种类型` = '大额医疗保险') then `t`.`单位缴` end))   AS `大额医疗保险-单位缴`,
       max((case when (`t`.`险种类型` = '大额医疗保险') then `t`.`个人缴` end))   AS `大额医疗保险-个人缴`,
       max((case when (`t`.`险种类型` = '公积金') then `t`.`单位缴` end))      AS `公积金-单位缴`,
       max((case when (`t`.`险种类型` = '公积金') then `t`.`个人缴` end))      AS `公积金-个人缴`
from `hr2020`.`welfare_tmp` `t`
group by `t`.`settlementPeriodId`, `t`.`结算期`, `t`.`treeSign`, `t`.`部门`, `t`.`岗位`, `t`.`姓名`, `t`.`工号`, `t`.`身份证号`
order by `t`.`deptCode`;

