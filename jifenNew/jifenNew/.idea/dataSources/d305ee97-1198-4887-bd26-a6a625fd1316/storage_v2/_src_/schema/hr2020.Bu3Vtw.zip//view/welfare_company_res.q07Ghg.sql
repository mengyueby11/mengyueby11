create view welfare_company_res as
select `t`.`settlementPeriodId` AS `settlementPeriodId`,
       `t`.`结算期`                AS `结算期`,
       sum(`t`.`合计缴纳`)          AS `合计缴纳`,
       sum(`t`.`单位缴`)           AS `单位缴`,
       sum(`t`.`个人缴`)           AS `个人缴`,
       count(`t`.`工号`)          AS `人数`
from `hr2020`.`welfare_person_res` `t`
group by `t`.`settlementPeriodId`, `t`.`结算期`;

