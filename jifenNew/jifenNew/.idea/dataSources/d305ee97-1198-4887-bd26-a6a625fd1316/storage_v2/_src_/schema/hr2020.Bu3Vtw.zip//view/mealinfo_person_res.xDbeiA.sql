create view mealinfo_person_res as
select `tt`.`结算期`          AS `结算期`,
       `tt`.`结算期`          AS `费款所属期`,
       `tt`.`deptCode`     AS `deptCode`,
       `tt`.`treeSign`     AS `treeSign`,
       `tt`.`部门`           AS `部门`,
       `tt`.`岗位`           AS `岗位`,
       `tt`.`姓名`           AS `姓名`,
       `tt`.`工号`           AS `工号`,
       `tt`.`身份证号`         AS `身份证号`,
       `tt`.`入职日期`         AS `入职日期`,
       `tt`.`员工状态`         AS `员工状态`,
       `tt`.`发放类型`         AS `发放类型`,
       `tt`.`餐费标准`         AS `餐费标准`,
       `tt`.`补上个月`         AS `补上个月`,
       `tt`.`小计`           AS `小计`,
       `tt`.`扣卡费`          AS `扣卡费`,
       `tt`.`hrMealInfoId` AS `hrMealInfoId`,
       `tt`.`扣款`           AS `扣款`
from `hr2020`.`mealinfo_res_tmp` `tt`;

