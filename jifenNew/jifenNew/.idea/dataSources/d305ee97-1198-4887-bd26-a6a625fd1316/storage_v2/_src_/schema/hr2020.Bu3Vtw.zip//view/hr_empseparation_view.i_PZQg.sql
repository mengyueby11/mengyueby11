create view hr_empseparation_view as
select `sepsep`.`separationId`        AS `separationId`,
       `sepsep`.`blackMemo`           AS `blackMemo`,
       `sepsep`.`blacklist`           AS `blacklist`,
       `sepsep`.`createTime`          AS `createTime`,
       `sepsep`.`deptName`            AS `deptName`,
       `sepsep`.`dutyId`              AS `dutyId`,
       `sepsep`.`dutyName`            AS `dutyName`,
       `sepsep`.`empInitStatus`       AS `empInitStatus`,
       `sepsep`.`empfileId`           AS `empfileId`,
       `sepsep`.`isApprovalSX`        AS `isApprovalSX`,
       `sepsep`.`isFanpin`            AS `isFanpin`,
       `sepsep`.`sendTime`            AS `sendTime`,
       `sepsep`.`separationApplyDate` AS `separationApplyDate`,
       `sepsep`.`separationDate`      AS `separationDate`,
       `sepsep`.`separationMemo`      AS `separationMemo`,
       `sepsep`.`separationReason`    AS `separationReason`,
       `sepsep`.`separationSXMemo`    AS `separationSXMemo`,
       `sepsep`.`separationState`     AS `separationState`,
       `sepsep`.`separationType`      AS `separationType`,
       `sepsep`.`titleName`           AS `titleName`,
       `sepsep`.`modifytime`          AS `modifytime`
from (`hr2020`.`emp_empseparation` `sepsep`
       join (select max(`sep`.`separationDate`) AS `mx`, `sep`.`empfileId` AS `empfileId`
             from `hr2020`.`emp_empseparation` `sep`
             group by `sep`.`empfileId`) `tttt`
            on (((`sepsep`.`empfileId` = `tttt`.`empfileId`) and (`tttt`.`mx` = `sepsep`.`separationDate`))))
order by `sepsep`.`separationDate` desc;

