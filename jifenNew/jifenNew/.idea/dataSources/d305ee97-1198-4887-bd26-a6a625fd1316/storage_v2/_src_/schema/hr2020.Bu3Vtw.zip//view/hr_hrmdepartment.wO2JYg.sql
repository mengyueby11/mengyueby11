create view hr_hrmdepartment as
select `dept`.`deptId`                   AS `id`,
       `dept`.`parentId`                 AS `supdepid`,
       `dept`.`companyId`                AS `subcompanyid1`,
       `dept`.`deptName`                 AS `departmentname`,
       `dept`.`treeSign`                 AS `treesign`,
       `dept`.`fullDeptName`             AS `departmentmark`,
       cast(`dept`.`deptCode` as signed) AS `showorder`,
       `dept`.`deptCode`                 AS `deptCode`,
       `dept`.`orderNo`                  AS `orderno`
from `hr2020`.`sys_department` `dept`
where ((`dept`.`treeSign` like '1-3-%') and (`dept`.`treeSign` <> '1-3-') and (`dept`.`useStatus` = 0) and
       (`dept`.`deptId` <> 527));

