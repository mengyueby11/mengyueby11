create view hr_hrmresource_manager as
select `myduty`.`dutyId` AS `dutyid`, `myuser`.`empid` AS `managerid`, `myuser`.`empNo` AS `empNo`
from (`hr2020`.`sys_duty` `myduty`
       left join ((select `user_`.`empId` AS `empid`, `user_`.`dutyId` AS `dutyid`, `user_`.`empNo` AS `empNo`
                   from `hr2020`.`sys_user` `user_`
                   where ((`user_`.`useStatus` = 0) and (`user_`.`empId` <> 1)))
                  union all
                  (select `ttttt`.`managerid` AS `empid`, `ttttt`.`dutyId` AS `dutyId`, `ttttt`.`empNo` AS `empNo`
                   from (select `fd`.`dutyId`                                                     AS `dutyId`,
                                `user_`.`empNo`                                                   AS `empNo`,
                                substring_index(group_concat(`fd`.`empId` separator ','), ',', 1) AS `managerid`
                         from (`hr2020`.`emp_parttimeduty` `fd`
                                left join `hr2020`.`sys_user` `user_` on ((`user_`.`useStatus` = 0)))
                         group by `fd`.`dutyId`) `ttttt`)) `myuser` on ((`myduty`.`parentId` = `myuser`.`dutyid`)))
where (`myuser`.`empid` is not null)
group by `myduty`.`dutyId`, `myuser`.`empid`, `myuser`.`empNo`
having (count(`myuser`.`empid`) = 1)
order by `myduty`.`dutyId`;

