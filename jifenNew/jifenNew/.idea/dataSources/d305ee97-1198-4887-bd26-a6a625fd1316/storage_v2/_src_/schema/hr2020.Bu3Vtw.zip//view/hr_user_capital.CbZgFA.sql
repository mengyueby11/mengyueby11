create view hr_user_capital as
select `ttt`.`emp_id`        AS `id`,
       `ttt`.`emp_id`        AS `emp_id`,
       `ttt`.`username`      AS `username`,
       `ttt`.`password`      AS `password`,
       0                     AS `age`,
       ''                    AS `email`,
       ''                    AS `photo`,
       ''                    AS `create_by`,
       ''                    AS `update_by`,
       '2020-06-22 14:20:48' AS `create_date`,
       '2020-06-22 14:20:48' AS `update_date`,
       `ttt`.`real_name`     AS `real_name`,
       `ttt`.`status`        AS `status`,
       `ttt`.`treesign`      AS `treesign`,
       `ttt`.`dept`          AS `dept`,
       0                     AS `del_flag`
from (select `su`.`empId`      AS `emp_id`,
             `su`.`empNo`      AS `username`,
             `su`.`password`   AS `password`,
             `su`.`empName`    AS `real_name`,
             `su`.`useStatus`  AS `status`,
             `dept`.`treeSign` AS `treesign`,
             `dept`.`deptId`   AS `dept`
      from (`hr2020`.`sys_user` `su`
             join `hr2020`.`sys_department` `dept` on ((`su`.`deptId` = `dept`.`deptId`)))) `ttt`;

