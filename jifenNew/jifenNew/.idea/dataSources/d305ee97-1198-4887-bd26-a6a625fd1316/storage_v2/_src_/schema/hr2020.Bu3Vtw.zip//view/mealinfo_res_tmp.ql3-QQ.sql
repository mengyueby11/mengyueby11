create view mealinfo_res_tmp as
select `period`.`hr_attend_period_id`                 AS `settlementPeriodId`,
       substr(`period`.`hr_attend_period_name`, 1, 4) AS `y`,
       substr(`period`.`hr_attend_period_name`, 5)    AS `m`,
       `period`.`hr_attend_period_name`               AS `结算期`,
       `dept`.`deptCode`                              AS `deptCode`,
       `dept`.`treeSign`                              AS `treeSign`,
       `dept`.`fullDeptName`                          AS `部门`,
       `duty`.`dutyName`                              AS `岗位`,
       `u`.`empName`                                  AS `姓名`,
       `u`.`empNo`                                    AS `工号`,
       `u`.`certifiCateNo`                            AS `身份证号`,
       `file`.`hireDate`                              AS `入职日期`,
       `ws`.`name`                                    AS `员工状态`,
       (case `info`.`hr_meal_info_type`
          when 1 then '正常发放'
          when 2 then '驻外不发'
          when 3 then '工资发放'
          when 4 then '考勤发放'
          when 5 then '停发'
          when 6 then '按500发放'
          else '' end)                                AS `发放类型`,
       `info`.`hr_meal_info_money`                    AS `餐费标准`,
       `info`.`hr_meal_up`                            AS `补上个月`,
       `info`.`hr_meal_realpay`                       AS `小计`,
       `info`.`hr_meal_up`                            AS `扣卡费`,
       `info`.`hr_meal_info_id`                       AS `hrMealInfoId`,
       `info`.`hr_up_money`                           AS `扣款`
from ((((((`hr2020`.`hr_meal_info` `info` left join `hr2020`.`sys_user` `u` on ((`u`.`empId` = `info`.`hr_emp_id`))) left join `hr2020`.`sys_duty` `duty` on ((`duty`.`dutyId` = `u`.`dutyId`))) left join `hr2020`.`sys_department` `dept` on ((`dept`.`deptId` = `u`.`deptId`))) left join `hr2020`.`hr_attend_period` `period` on ((`period`.`hr_attend_period_id` = `info`.`hr_period_id`))) left join `hr2020`.`emp_employeefile` `file` on ((`file`.`empId` = `u`.`empId`)))
       left join `hr2020`.`sys_workstatus` `ws` on ((`ws`.`statusCode` = `file`.`workStatus`)))
where (`dept`.`treeSign` like '1-3-%')
order by `period`.`hr_attend_period_name` desc, `dept`.`deptCode`;

