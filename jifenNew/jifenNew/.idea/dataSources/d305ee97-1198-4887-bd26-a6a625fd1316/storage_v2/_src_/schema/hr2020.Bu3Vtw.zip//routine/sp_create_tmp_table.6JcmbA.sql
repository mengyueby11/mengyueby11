create
  definer = root@`%` procedure sp_create_tmp_table(IN qj varchar(20), IN qj1 varchar(20))
BEGIN
SET @drop_table_sql = CONCAT("DROP TABLE IF EXISTS ",'hr_tmp_考勤汇总_',qj);
SET @create_table_sql = CONCAT('CREATE TABLE ','hr_tmp_考勤汇总_',qj,
" (
  结算期 varchar(10) DEFAULT NULL,
  费款所属期 varchar(10) DEFAULT NULL,
  deptCode varchar(50) DEFAULT NULL,
  treeSign varchar(25) DEFAULT NULL,
  部门 varchar(50) DEFAULT NULL,
  岗位 varchar(50) DEFAULT NULL,
  姓名 varchar(10) DEFAULT NULL,
  工号 varchar(10) DEFAULT NULL,
  empId bigint(20) DEFAULT NULL,
  身份证号 varchar(50) DEFAULT NULL,
  应出勤 double(5,1) DEFAULT NULL,
  实出勤 double(5,1) DEFAULT NULL,
  早退 int(4) DEFAULT NULL,
  迟到 int(4) DEFAULT NULL,
  旷工 double(4,1) DEFAULT NULL,
  事假 double(4,1) DEFAULT NULL,
  公出 double(4,1) DEFAULT NULL,
  病假 double(4,1) DEFAULT NULL,
  丧假 double(4,1) DEFAULT NULL,
  年假 double(4,1) DEFAULT NULL,
  产假 double(4,1) DEFAULT NULL,
  产检假 double(4,1) DEFAULT NULL,
  婚假 double(4,1) DEFAULT NULL,
  工伤假 double(4,1) DEFAULT NULL,
  特别纪念日假 double(4,1) DEFAULT NULL,
  平常日加班 double(4,1) DEFAULT NULL,
  公休日加班 double(4,1) DEFAULT NULL,
  节假日加班 double(4,1) DEFAULT NULL,
  上午上班缺刷卡 int(4) DEFAULT NULL,
  上午下班缺刷卡 int(4) DEFAULT NULL,
  下午上班缺刷卡 int(4) DEFAULT NULL,
  下午下班缺刷卡 int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
");
SET @drop_table_sql1 = CONCAT("DROP TABLE IF EXISTS ",'hr_tmp_餐补汇总_',qj1);
SET @create_table_sql1 = CONCAT('CREATE TABLE ','hr_tmp_餐补汇总_',qj1,
" (
 结算期 varchar(10) DEFAULT NULL,
  费款所属期 varchar(10) DEFAULT NULL,
  deptCode varchar(50) DEFAULT NULL,
  treeSign varchar(25) DEFAULT NULL,
  部门 varchar(50) DEFAULT NULL,
  岗位 varchar(50) DEFAULT NULL,
  姓名 varchar(10) DEFAULT NULL,
  工号 varchar(10) DEFAULT NULL,
  身份证号 varchar(50) DEFAULT NULL,
  入职日期 varchar(30) DEFAULT NULL,
  员工状态 varchar(10) DEFAULT NULL,
  发放类型 varchar(10) DEFAULT NULL,
  餐费标准 double(10,2) DEFAULT NULL,
  补上个月 double(10,2) DEFAULT NULL,
  小计 double(10,2) DEFAULT NULL,
  扣卡费 double(10,2) DEFAULT NULL,
  扣款 double(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
");
SET @drop_table_sql2 = CONCAT("DROP TABLE IF EXISTS ",'hr_tmp_福利汇总_',qj1);
SET @create_table_sql2 = CONCAT('CREATE TABLE ','hr_tmp_福利汇总_',qj1,
" (
  `结算期` varchar(10) DEFAULT NULL,
  `deptCode` varchar(50) DEFAULT NULL,
  `treeSign` varchar(25) DEFAULT NULL,
  `部门` varchar(50) DEFAULT NULL,
  `岗位` varchar(50) DEFAULT NULL,
  `姓名` varchar(10) DEFAULT NULL,
  `工号` varchar(10) DEFAULT NULL,
  `身份证号` varchar(50) DEFAULT NULL,
  `合计缴纳` double(10,2) DEFAULT NULL,
  `利息` double(10,2) DEFAULT NULL,
  `滞纳金` double(10,2) DEFAULT NULL,
  `企业基本养老保险-单位缴` double(10,2) DEFAULT NULL,
  `企业基本养老保险-个人缴` double(10,2) DEFAULT NULL,
  `失业保险-单位缴` double(10,2) DEFAULT NULL,
  `失业保险-个人缴` double(10,2) DEFAULT NULL,
  `基本医疗保险-单位缴` double(10,2) DEFAULT NULL,
  `基本医疗保险-个人缴` double(10,2) DEFAULT NULL,
  `工伤保险-单位缴` double(10,2) DEFAULT NULL,
  `工伤保险-个人缴` double(10,2) DEFAULT NULL,
  `生育保险-单位缴` double(10,2) DEFAULT NULL,
  `生育保险-个人缴` double(10,2) DEFAULT NULL,
  `大额医疗保险-单位缴` double(10,2) DEFAULT NULL,
  `大额医疗保险-个人缴` double(10,2) DEFAULT NULL,
  `公积金-单位缴` double(10,2) DEFAULT NULL,
  `公积金-个人缴` double(10,2) DEFAULT NULL,
  `单位缴` double(10,2) DEFAULT NULL,
  `个人缴` double(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
");
SET @drop_table_sql3 = CONCAT("DROP TABLE IF EXISTS ",'hr_tmp_考勤汇总_',qj,'_next');
SET @create_table_sql3 = CONCAT('CREATE TABLE ','hr_tmp_考勤汇总_',qj,'_next',
" (
  结算期 varchar(10) DEFAULT NULL,
  费款所属期 varchar(10) DEFAULT NULL,
  deptCode varchar(50) DEFAULT NULL,
  treeSign varchar(25) DEFAULT NULL,
  部门 varchar(50) DEFAULT NULL,
  岗位 varchar(50) DEFAULT NULL,
  姓名 varchar(10) DEFAULT NULL,
  工号 varchar(10) DEFAULT NULL,
  身份证号 varchar(50) DEFAULT NULL,
  应出勤 double(5,1) DEFAULT NULL,
  实出勤 double(5,1) DEFAULT NULL,
  早退 int(4) DEFAULT NULL,
  迟到 int(4) DEFAULT NULL,
  旷工 int(4) DEFAULT NULL,
  事假 double(4,1) DEFAULT NULL,
  公出 double(4,1) DEFAULT NULL,
  病假 double(4,1) DEFAULT NULL,
  丧假 double(4,1) DEFAULT NULL,
  年假 double(4,1) DEFAULT NULL,
  产假 double(4,1) DEFAULT NULL,
  产检假 double(4,1) DEFAULT NULL,
  婚假 double(4,1) DEFAULT NULL,
  工伤假 double(4,1) DEFAULT NULL,
  特别纪念日假 double(4,1) DEFAULT NULL,
  平常日加班 double(4,1) DEFAULT NULL,
  公休日加班 double(4,1) DEFAULT NULL,
  节假日加班 double(4,1) DEFAULT NULL,
  上午上班缺刷卡 int(4) DEFAULT NULL,
  上午下班缺刷卡 int(4) DEFAULT NULL,
  下午上班缺刷卡 int(4) DEFAULT NULL,
  下午下班缺刷卡 int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
");
SET @drop_table_sql4 = CONCAT("DROP TABLE IF EXISTS ",'hr_tmp_考勤明细_',qj);
SET @create_table_sql4 = CONCAT('CREATE TABLE ','hr_tmp_考勤明细_',qj,
" (
  结算期 varchar(10) DEFAULT NULL,
  费款所属期 varchar(10) DEFAULT NULL,
  日期 varchar(10) DEFAULT NULL,
  deptCode varchar(50) DEFAULT NULL,
  treeSign varchar(25) DEFAULT NULL,
  部门 varchar(50) DEFAULT NULL,
  岗位 varchar(50) DEFAULT NULL,
  姓名 varchar(10) DEFAULT NULL,
  工号 varchar(10) DEFAULT NULL,
  empId bigint(20) DEFAULT NULL,
  身份证号 varchar(50) DEFAULT NULL,
  应出勤 double(5,1) DEFAULT NULL,
  实出勤 double(5,1) DEFAULT NULL,
  早退 int(4) DEFAULT NULL,
  迟到 int(4) DEFAULT NULL,
  旷工 double(4,1) DEFAULT NULL,
  事假 double(4,1) DEFAULT NULL,
  公出 double(4,1) DEFAULT NULL,
  病假 double(4,1) DEFAULT NULL,
  丧假 double(4,1) DEFAULT NULL,
  年假 double(4,1) DEFAULT NULL,
  产假 double(4,1) DEFAULT NULL,
  产检假 double(4,1) DEFAULT NULL,
  婚假 double(4,1) DEFAULT NULL,
  工伤假 double(4,1) DEFAULT NULL,
  特别纪念日假 double(4,1) DEFAULT NULL,
  平常日加班 double(4,1) DEFAULT NULL,
  公休日加班 double(4,1) DEFAULT NULL,
  节假日加班 double(4,1) DEFAULT NULL,
  上午上班缺刷卡 int(4) DEFAULT NULL,
  上午下班缺刷卡 int(4) DEFAULT NULL,
  下午上班缺刷卡 int(4) DEFAULT NULL,
  下午下班缺刷卡 int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
");
PREPARE drop_table_sql FROM @drop_table_sql;
PREPARE create_table_sql FROM @create_table_sql;
PREPARE drop_table_sql1 FROM @drop_table_sql1;
PREPARE create_table_sql1 FROM @create_table_sql1;
PREPARE drop_table_sql2 FROM @drop_table_sql2;
PREPARE create_table_sql2 FROM @create_table_sql2;
PREPARE drop_table_sql3 FROM @drop_table_sql3;
PREPARE create_table_sql3 FROM @create_table_sql3;
PREPARE drop_table_sql4 FROM @drop_table_sql4;
PREPARE create_table_sql4 FROM @create_table_sql4;
EXECUTE drop_table_sql;
EXECUTE create_table_sql;
EXECUTE drop_table_sql1;
EXECUTE create_table_sql1;
EXECUTE drop_table_sql2;
EXECUTE create_table_sql2;
EXECUTE drop_table_sql3;
EXECUTE create_table_sql3;
EXECUTE drop_table_sql4;
EXECUTE create_table_sql4;
END;

