create view nnn as
select round(substring_index(`dd`.`hr_column_value`, ':', -(1)), 2) AS `val`, `dd`.`hr_emp_id` AS `empid`
from `hr2020`.`hr_emp_salary` `dd`
where (`dd`.`hr_attend_period` = 555)
order by `dd`.`hr_emp_id`;

