create view hr_hrmresource1 as
select distinct `user_`.`empId`                                                                   AS `id`,
                `file_`.`empfileId`                                                               AS `empfileid`,
                `user_`.`empNo`                                                                   AS `workcode`,
                `user_`.`empNo`                                                                   AS `loginid`,
                `user_`.`empName`                                                                 AS `lastname`,
                `duty_`.`deptId`                                                                  AS `departmentid`,
                `depart_`.`fullDeptName`                                                          AS `fullDeptName`,
                cast(substr(substring_index(`dept_`.`treeSign`, '-', 3),
                            (length(substring_index(`dept_`.`treeSign`, '-', 2)) + 2)) as signed) AS `top_departmentid`,
                `dept_`.`treeSign`                                                                AS `treeSign`,
                `duty_`.`dutyId`                                                                  AS `jobtitle`,
                `duty_`.`dutyName`                                                                AS `dutyName`,
                upper(`user_`.`password`)                                                         AS `password`,
                cast(`user_`.`sex` as char(1) charset utf8)                                       AS `sex`,
                date_format(`file_`.`birthdate`, '%Y-%m-%d')                                      AS `birthday`,
                1                                                                                 AS `systemlanguage`,
                `file_`.`maritalStatus`                                                           AS `maritalstatus`,
                `user_`.`mobileTel`                                                               AS `telephone`,
                `user_`.`mobileTel`                                                               AS `mobile`,
                `file_`.`email`                                                                   AS `email`,
                0                                                                                 AS `locationid`,
                ''                                                                                AS `startdate`,
                ''                                                                                AS `enddate`,
                (case
                   when (`duty_`.`dutyLevel` = '1') then 10
                   when (`duty_`.`dutyLevel` = '2') then 40
                   when (`duty_`.`dutyLevel` = '3') then 60
                   when (`duty_`.`dutyLevel` = '4') then 80
                   when (`duty_`.`dutyLevel` = '5') then 90
                   else 10 end)                                                                   AS `seclevel`,
                upper(`user_`.`certifiCateNo`)                                                    AS `certificatenum`,
                ifnull(`np`.`name`, '')                                                           AS `nativeplace`,
                `edu`.`education`                                                                 AS `educationlevel`,
                if((`yyy`.`isApprovalSX` = 3), 2, `file_`.`workStatus`)                           AS `status`,
                `file_`.`familyAddress`                                                           AS `homeaddress`,
                0                                                                                 AS `dsporder`,
                date_format(`file_`.`hireDate`, '%Y-%m-%d')                                       AS `sartht`,
                `nation`.`name`                                                                   AS `folk`,
                `file_`.`birthPlace`                                                              AS `birthPlace`,
                `political`.`dicName`                                                             AS `policy`,
                `degreedic`.`dicName`                                                             AS `degree`,
                date_format(`yyy`.`mx`, '%Y-%m-%d')                                               AS `separationDate`,
                `yyy`.`isApprovalSX`                                                              AS `isApprovalSX`,
                date_format(`file_`.`realFormalDate`, '%Y-%m-%d')                                 AS `formalDate`,
                `ttttt`.`managerid`                                                               AS `managerid`
from (((((((((((((`hr2020`.`sys_user` `user_` join `hr2020`.`emp_employeefile` `file_` on ((`user_`.`empId` = `file_`.`empId`))) left join (select max(`sep`.`separationDate`) AS `mx`,
                                                                                                                                                   `sep`.`isApprovalSX`        AS `isApprovalSX`,
                                                                                                                                                   `sep`.`empfileId`           AS `empfileId`
                                                                                                                                            from `hr2020`.`emp_empseparation` `sep`
                                                                                                                                            group by `sep`.`empfileId`) `yyy` on ((`yyy`.`empfileId` = `file_`.`empfileId`))) join `hr2020`.`sys_duty` `duty_` on ((`user_`.`dutyId` = `duty_`.`dutyId`))) join `hr2020`.`sys_department` `depart_` on ((
    (`user_`.`deptId` = `depart_`.`deptId`) and
    (`duty_`.`deptId` = `depart_`.`deptId`)))) left join `hr2020`.`sys_nativeplace` `np` on ((`np`.`code` = `file_`.`nativePlace`))) left join `hr2020`.`sys_dictionary` `maritaldic` on ((`maritaldic`.`dicId` = `file_`.`maritalStatus`))) left join (select `edu`.`empfileId` AS `empfileId`,
                                                                                                                                                                                                                                                               substring_index(
                                                                                                                                                                                                                                                                   group_concat(
                                                                                                                                                                                                                                                                       `edu`.`education`
                                                                                                                                                                                                                                                                       order
                                                                                                                                                                                                                                                                       by
                                                                                                                                                                                                                                                                       `edu`.`endDate`
                                                                                                                                                                                                                                                                       DESC
                                                                                                                                                                                                                                                                       separator
                                                                                                                                                                                                                                                                       ','),
                                                                                                                                                                                                                                                                   ',',
                                                                                                                                                                                                                                                                   1)            AS `education`,
                                                                                                                                                                                                                                                               substring_index(
                                                                                                                                                                                                                                                                   group_concat(
                                                                                                                                                                                                                                                                       `edu`.`degree`
                                                                                                                                                                                                                                                                       order
                                                                                                                                                                                                                                                                       by
                                                                                                                                                                                                                                                                       `edu`.`endDate`
                                                                                                                                                                                                                                                                       DESC
                                                                                                                                                                                                                                                                       separator
                                                                                                                                                                                                                                                                       ','),
                                                                                                                                                                                                                                                                   ',',
                                                                                                                                                                                                                                                                   1)            AS `degree`
                                                                                                                                                                                                                                                        from `hr2020`.`emp_education` `edu`
                                                                                                                                                                                                                                                        where (`edu`.`empfileId` is not null)
                                                                                                                                                                                                                                                        group by `edu`.`empfileId`) `edu` on ((`file_`.`empfileId` = `edu`.`empfileId`))) left join `hr2020`.`sys_dictionary` `edudic` on ((`edudic`.`dicId` = `edu`.`education`))) left join `hr2020`.`sys_dictionary` `degreedic` on ((`degreedic`.`dicId` = `edu`.`degree`))) left join `hr2020`.`sys_nationality` `nation` on ((`nation`.`id` = `file_`.`nationality`))) left join `hr2020`.`sys_dictionary` `political` on ((`political`.`dicId` = `file_`.`politicalStatus`))) left join `hr2020`.`hr_hrmresource_manager` `ttttt` on ((
    (`duty_`.`dutyId` = `ttttt`.`dutyid`) and (`ttttt`.`dutyid` is not null))))
       left join `hr2020`.`sys_department` `dept_` on ((`duty_`.`deptId` = `dept_`.`deptId`)))
where ((1 = 1) and
       ((`file_`.`entryStatus` in (1, 2, 3, 4)) or ((`file_`.`entryStatus` = 5) and (`yyy`.`mx` >= '2018-01-01'))) and
       (`depart_`.`treeSign` like convert(concat('1-3-', '%') using utf8)));

