create view mmm as
select substring_index(substring_index(`dd`.`hr_column_value`, 'XZ0600', -(1)), ':', -(1)) AS `val`,
       `dd`.`hr_emp_id`                                                                    AS `empid`
from `hr2020`.`hr_startup_detail` `dd`
where ((`dd`.`hr_attend_period` = 555) and (`dd`.`hr_pay_type` = 0))
order by `dd`.`hr_emp_id`;

