create definer = mysql@`%` trigger `insert`
  after INSERT
  on emp_empseparation
  for each row
begin
#计算离职时间-入职时间，后面用来判断在职流失和试用期流失
declare ls int;
set ls = IFNULL((select replace(left(new.separationDate,7),'-','') - replace(left(hireDate,7),'-','') from emp_employeefile where empfileId=new.empfileId),0);

#更新历史报表中，该离职记录hireDate当月数据
update reportData set qmrs = qmrs-1,lzrs = lzrs+1,
zzls = zzls+if(ls>3,1,0),
syqls = syqls+if(ls>3,0,1)
where 
deptId2 = (select deptId from sys_department c where INSTR((select treeSign from sys_duty a,sys_department b where a.deptId=b.deptId and a.dutyId=new.dutyId),c.treeSign) and LENGTH(treeSign) - LENGTH( REPLACE(treeSign,'-','') )<=4 order by treeSign desc limit 1) and month = left(new.separationDate,7);

#更新历史报表中，该离职记录hireDate当月以后的数据
update reportData set qmrs = qmrs-1,qcrs=qcrs-1
where 
deptId2 = (select deptId from sys_department c where INSTR((select treeSign from sys_duty a,sys_department b where a.deptId=b.deptId and a.dutyId=new.dutyId),c.treeSign) and LENGTH(treeSign) - LENGTH( REPLACE(treeSign,'-','') )<=4 order by treeSign desc limit 1) and month > left(new.separationDate,7);



end;

