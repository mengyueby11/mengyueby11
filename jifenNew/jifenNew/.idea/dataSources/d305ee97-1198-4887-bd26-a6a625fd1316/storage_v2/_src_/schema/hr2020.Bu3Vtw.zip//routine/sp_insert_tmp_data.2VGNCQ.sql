create
  definer = root@`%` procedure sp_insert_tmp_data(IN qj varchar(20), IN qj1 varchar(20))
BEGIN
SET @delete_data_sql = CONCAT(" DELETE FROM ","hr_tmp_考勤汇总_",qj," WHERE 结算期=",qj);
SET @insert_data_sql = CONCAT(" INSERT INTO ",'hr_tmp_考勤汇总_',qj,"
SELECT
结算期,
费款所属期,
deptCode,
treeSign,
部门,
岗位,
姓名,
工号,
empId,
身份证号,
应出勤,
实出勤,
早退,
迟到,
旷工,
事假,
公出,
病假,
丧假,
年假,
产假,
产检假,
婚假,
工伤假,
特别纪念日假,
平常日加班,
公休日加班,
节假日加班,
上午上班缺刷卡,
上午下班缺刷卡,
下午上班缺刷卡,
下午下班缺刷卡
FROM attend_person_res
WHERE 结算期=",qj,"
");
SET @delete_data_sql3 = CONCAT(" DELETE FROM ","hr_tmp_考勤汇总_",qj,'_next'," WHERE 结算期=",qj1);
SET @insert_data_sql3 = CONCAT(" INSERT INTO ",'hr_tmp_考勤汇总_',qj,'_next',"
SELECT
结算期,
费款所属期,
deptCode,
treeSign,
部门,
岗位,
姓名,
工号,
身份证号,
应出勤,
实出勤,
早退,
迟到,
旷工,
事假,
公出,
病假,
丧假,
年假,
产假,
产检假,
婚假,
工伤假,
特别纪念日假,
平常日加班,
公休日加班,
节假日加班,
上午上班缺刷卡,
上午下班缺刷卡,
下午上班缺刷卡,
下午下班缺刷卡
FROM attend_person_res
WHERE 结算期=",qj1,"
");
SET @delete_data_sql1 = CONCAT(" DELETE FROM ","hr_tmp_餐补汇总_",qj1," WHERE 结算期=",qj1);
SET @insert_data_sql1 = CONCAT(" INSERT INTO ",'hr_tmp_餐补汇总_',qj1,"
SELECT
结算期,
费款所属期,
deptCode,
treeSign,
部门,
岗位,
姓名,
工号,
身份证号,
入职日期,
员工状态,
发放类型,
餐费标准,
补上个月,
小计,
扣卡费,
扣款
FROM
mealinfo_person_res
WHERE 结算期=",qj1,"
");
SET @delete_data_sql2 = CONCAT(" DELETE FROM ","hr_tmp_福利汇总_",qj1," WHERE 结算期=",qj1);
SET @insert_data_sql2 = CONCAT(" INSERT INTO ",'hr_tmp_福利汇总_',qj1,"
SELECT
`结算期`,
deptCode,
treeSign,
`部门`,
`岗位`,
`姓名`,
`工号`,
`身份证号`,
`合计缴纳`,
`利息`,
`滞纳金`,
`企业基本养老保险-单位缴`,
`企业基本养老保险-个人缴`,
`失业保险-单位缴`,
`失业保险-个人缴`,
`基本医疗保险-单位缴`,
`基本医疗保险-个人缴`,
`工伤保险-单位缴`,
`工伤保险-个人缴`,
`生育保险-单位缴`,
`生育保险-个人缴`,
`大额医疗保险-单位缴`,
`大额医疗保险-个人缴`,
`公积金-单位缴`,
`公积金-个人缴`,
`单位缴`,
`个人缴`
FROM
welfare_person_res
WHERE 结算期=",qj1,"
");
SET @delete_data_sql4 = CONCAT(" DELETE FROM ","hr_tmp_考勤明细_",qj," WHERE 结算期=",qj);
SET @insert_data_sql4 = CONCAT(" INSERT INTO ",'hr_tmp_考勤明细_',qj,"
SELECT
结算期,
费款所属期,
日期,
deptCode,
treeSign,
部门,
岗位,
姓名,
工号,
empId,
身份证号,
应出勤,
实出勤,
早退,
迟到,
旷工,
事假,
公出,
病假,
丧假,
年假,
产假,
产检假,
婚假,
工伤假,
特别纪念日假,
平常日加班,
公休日加班,
节假日加班,
上午上班缺刷卡,
上午下班缺刷卡,
下午上班缺刷卡,
下午下班缺刷卡
FROM attend_mx_person_res
WHERE 结算期=",qj,"
");

PREPARE delete_data_sql FROM @delete_data_sql;
EXECUTE delete_data_sql;
PREPARE insert_table_sql FROM @insert_data_sql;
EXECUTE insert_table_sql;
PREPARE delete_data_sql1 FROM @delete_data_sql1;
EXECUTE delete_data_sql1;
PREPARE insert_table_sql1 FROM @insert_data_sql1;
EXECUTE insert_table_sql1;
PREPARE delete_data_sql2 FROM @delete_data_sql2;
EXECUTE delete_data_sql2;
PREPARE insert_table_sql2 FROM @insert_data_sql2;
EXECUTE insert_table_sql2;
PREPARE delete_data_sql3 FROM @delete_data_sql3;
EXECUTE delete_data_sql3;
PREPARE insert_table_sql3 FROM @insert_data_sql3;
EXECUTE insert_table_sql3;
PREPARE delete_data_sql4 FROM @delete_data_sql4;
EXECUTE delete_data_sql4;
PREPARE insert_table_sql4 FROM @insert_data_sql4;
EXECUTE insert_table_sql4;
END;

