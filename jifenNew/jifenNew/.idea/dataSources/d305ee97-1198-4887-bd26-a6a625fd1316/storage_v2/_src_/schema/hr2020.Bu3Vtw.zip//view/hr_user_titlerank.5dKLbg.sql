create view hr_user_titlerank as
select `ttt`.`id`            AS `id`,
       `ttt`.`emp_id`        AS `emp_id`,
       `ttt`.`period_id`     AS `period_id`,
       `ttt`.`title_rank_id` AS `title_rank_id`,
       `ttt`.`create_time`   AS `create_time`,
       `ttt`.`obtain_time`   AS `obtain_time`,
       `ttt`.`operator_id`   AS `operator_id`,
       `dic`.`dicName`       AS `dicName`
from (((select `a`.`id`            AS `id`,
               `a`.`emp_id`        AS `emp_id`,
               `a`.`period_id`     AS `period_id`,
               `a`.`title_rank_id` AS `title_rank_id`,
               `a`.`create_time`   AS `create_time`,
               `a`.`obtain_time`   AS `obtain_time`,
               `a`.`operator_id`   AS `operator_id`
        from `hr2020`.`emp_title_rank` `a`
        where (`a`.`id` = (select `hr2020`.`emp_title_rank`.`id`
                           from `hr2020`.`emp_title_rank`
                           where (`a`.`emp_id` = `hr2020`.`emp_title_rank`.`emp_id`)
                           order by `hr2020`.`emp_title_rank`.`period_id` desc,
                                    `hr2020`.`emp_title_rank`.`obtain_time` desc
                           limit 1)))) `ttt`
       left join `hr2020`.`sys_dictionary` `dic` on ((`dic`.`dicId` = `ttt`.`title_rank_id`)));

