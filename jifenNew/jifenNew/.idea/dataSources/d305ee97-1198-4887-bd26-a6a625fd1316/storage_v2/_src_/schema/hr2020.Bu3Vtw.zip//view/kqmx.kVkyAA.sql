create view kqmx as
select `had`.`hr_attend_period`            AS `日期`,
       `sdept`.`deptCode`                  AS `deptCode`,
       `sdept`.`treeSign`                  AS `treeSign`,
       `sdept`.`fullDeptName`              AS `部门`,
       `sd`.`dutyName`                     AS `岗位`,
       `su`.`empName`                      AS `姓名`,
       `su`.`empNo`                        AS `工号`,
       `su`.`empId`                        AS `empId`,
       `su`.`certifiCateNo`                AS `身份证号`,
       `had`.`hr_attend_need`              AS `应出勤`,
       `had`.`hr_attend_fact`              AS `实出勤`,
       `had`.`hr_attend_early`             AS `早退`,
       `had`.`hr_attend_late`              AS `迟到`,
       `had`.`hr_attend_absent`            AS `旷工`,
       `had`.`hr_attend_private`           AS `事假`,
       `had`.`hr_attend_travel`            AS `公出`,
       `had`.`hr_attend_sick`              AS `病假`,
       `had`.`hr_attend_funeral`           AS `丧假`,
       `had`.`hr_attend_annual`            AS `年假`,
       `had`.`hr_attend_maternity`         AS `产假`,
       `had`.`hr_attend_check`             AS `产检假`,
       `had`.`hr_attend_marry`             AS `婚假`,
       `had`.`hr_attend_injury`            AS `工伤假`,
       `had`.`hr_attend_other`             AS `特别纪念日假`,
       `had`.`hr_attend_usual`             AS `平常日加班`,
       `had`.`hr_attend_holiday`           AS `公休日加班`,
       `had`.`hr_attend_vacation`          AS `节假日加班`,
       (case
          when (`had`.`hr_attend_absent` = 1) then 0
          when ((`had`.`hr_attend_absent` = 0.5) and (`had`.`hr_attend_on1` = 1) and (`had`.`hr_attend_off1` = 1))
            then 0
          else `had`.`hr_attend_on1` end)  AS `上午上班缺刷卡`,
       (case
          when (`had`.`hr_attend_absent` = 1) then 0
          when ((`had`.`hr_attend_absent` = 0.5) and (((`had`.`hr_attend_on1` = 1) and (`had`.`hr_attend_off1` = 1)) or
                                                      ((`had`.`hr_attend_off1` = 1) and (`had`.`hr_attend_on2` = 1))))
            then 0
          else `had`.`hr_attend_off1` end) AS `上午下班缺刷卡`,
       (case
          when (`had`.`hr_attend_absent` = 1) then 0
          when ((`had`.`hr_attend_absent` = 0.5) and (((`had`.`hr_attend_off1` = 1) and (`had`.`hr_attend_on2` = 1)) or
                                                      ((`had`.`hr_attend_on2` = 1) and (`had`.`hr_attend_off2` = 1))))
            then 0
          else `had`.`hr_attend_on2` end)  AS `下午上班缺刷卡`,
       (case
          when (`had`.`hr_attend_absent` = 1) then 0
          when ((`had`.`hr_attend_absent` = 0.5) and (`had`.`hr_attend_on2` = 1) and (`had`.`hr_attend_off2` = 1))
            then 0
          else `had`.`hr_attend_off2` end) AS `下午下班缺刷卡`
from (((`hr2020`.`hr_attendance_data` `had` left join `hr2020`.`sys_user` `su` on ((`had`.`hr_emp_id` = `su`.`empId`))) left join `hr2020`.`sys_duty` `sd` on ((`su`.`dutyId` = `sd`.`dutyId`)))
       left join `hr2020`.`sys_department` `sdept` on ((`sd`.`deptId` = `sdept`.`deptId`)))
where (`sdept`.`treeSign` like '1-3-%');

