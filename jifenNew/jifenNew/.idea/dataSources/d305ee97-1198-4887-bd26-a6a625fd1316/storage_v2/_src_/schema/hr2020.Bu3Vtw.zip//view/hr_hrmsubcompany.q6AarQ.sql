create view hr_hrmsubcompany as
select `dept`.`fullDeptName` AS `subcompanydesc`,
       `dept`.`companyId`    AS `companyid`,
       `dept`.`deptName`     AS `subcompanyname`,
       `dept`.`deptCode`     AS `subcompanycode`,
       `dept`.`deptId`       AS `subcompanyid`,
       `dept`.`deptId`       AS `id`
from `hr2020`.`sys_department` `dept`
where (`dept`.`treeSign` = '1-3-');

