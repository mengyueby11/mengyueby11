create view hr_emp_duty_level as
select `hdi`.`emp_id` AS `emp_id`, concat(`hdtg`.`remark`, '-', `hdtg`.`title_name`) AS `remark`
from (`hr2020`.`hr_define_integral` `hdi`
       left join `hr2020`.`hr_define_title_grade` `hdtg` on ((`hdi`.`grade_id` = `hdtg`.`id`)));

