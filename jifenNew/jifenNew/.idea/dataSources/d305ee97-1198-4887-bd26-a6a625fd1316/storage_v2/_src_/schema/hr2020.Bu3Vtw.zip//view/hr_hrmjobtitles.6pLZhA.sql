create view hr_hrmjobtitles as
select `duty`.`dutyId`   AS `id`,
       `duty`.`dutyName` AS `jobtitlename`,
       `duty`.`dutyDesc` AS `jobtitlemark`,
       `duty`.`deptId`   AS `jobdeptid`
from (`hr2020`.`sys_duty` `duty`
       join `hr2020`.`sys_department` `dept`
            on (((`duty`.`deptId` = `dept`.`deptId`) and (`dept`.`useStatus` = 0) and (`dept`.`treeSign` <> '1-3-') and
                 (`dept`.`treeSign` like '1-3-%') and (`duty`.`useStatus` = 0) and (`dept`.`useStatus` = 0))));

